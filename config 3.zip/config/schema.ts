import { z } from "zod";

const OllamaModelConfig = z.object({
    name: z.string().min(2).max(100),
    temperature: z.number().min(0).max(1).optional(),
    repeat_penalty: z.number().min(1).max(2).optional()
});

const HFModelConfig = z.object({
    name: z.string().min(2).max(100),
    cacheDir: z.string().min(2).max(100).optional()
});

const PreProcessSplitByPageConfig = z.object({
    separator: z.string().optional().default("\n\n"),
    chunkSize: z.number().min(1).default(1024),
    overlap: z.number().min(0).default(0)
})

const PreProcessSplitByArticleConfig = z.object({
    footerRatio: z.number().min(0).max(1).default(0.92),
    collectionName: z.string().min(1).max(100).default("splitByArticleWithHybridSearch"),
    multiplier: z.number().min(1).default(2)
});

const PreProcessConfig = z.object({
    extensions: z.array(z.string()).optional(),
    splitByPage: PreProcessSplitByPageConfig.optional(),
    splitByArticle: PreProcessSplitByArticleConfig.optional(),
});

const ResponseFormatPrompt = z.object({
    description: z.string(),
    format: z.string(),
    example: z.string()
});

const RAGHybridSearchConfig = z.object({
    vector_only: z.boolean().optional().default(false),
    bm25_only: z.boolean().optional().default(false),
    vector_weight: z.number().min(0).max(1).optional().default(0.5),
    bm25_weight: z.number().min(0).max(1).optional().default(0.5),
    bm25_params: z.object({
        k1: z.number().optional().default(1.5),
        b: z.number().optional().default(0.75)
    }).optional()
});


export const AppConfigSchema = z.object({
    APP_MODE: z.enum(['development', 'production', 'rag-evaluation']),
    ApacheSolr: z.object({
        url: z.url(),
        coreName: z.string().min(2).max(100)
    }),
    MySQL: z.object({
        host: z.string().min(2).max(100),
        port: z.number().min(1).max(65535),
        user: z.string().min(2).max(100),
        password: z.string().min(8).max(100),
        database: z.string().min(2).max(100)
    }),
    Redis: z.object({
        host: z.string().min(2).max(100),
        port: z.number().min(1).max(65535),
        password: z.string().min(8).max(100),
        database: z.number().min(0)
    }),
    Ollama: z.object({
        url: z.array(z.url()).min(1),
        model: z.string().min(1)
    }),
    Models: z.object({
        chatModel: OllamaModelConfig,
        chatTitleGenModel: OllamaModelConfig,
        chatKeywordGenModel: OllamaModelConfig,
        summaryGenModel: OllamaModelConfig,
        translateModel: OllamaModelConfig,
        ragEmbeddingModel: HFModelConfig,
        ragRerankModel: HFModelConfig
    }),
    Frontend: z.object({
        host: z.string().min(1),
        port: z.number().min(1).max(65535)
    }),
    Backend: z.object({
        host: z.string().min(1),
        port: z.number().min(1).max(65535),
        jwtSecret: z.string().min(1),
        jwtRefreshSecret: z.string().min(1),
        logTime: z.string().min(1),
        Tokenizer: z.object({
            charactersPerToken: z.number().min(1),
        }),
        ModelContextWindowLimits: z.object({
            totalLimit: z.number().min(1), // tokens - adjust for your specific model
            systemPromptReserve: z.number().min(1), // tokens reserved for system prompt
            formattingReserve: z.number().min(1), // tokens reserved for formatting
            outputReserve: z.number().min(1), // tokens reserved for model output
        })
    }),
    RAG: z.object({
        Backend: z.object({
            host: z.string().min(1),
            port: z.number().min(1).max(65535),
            url: z.url().min(1)
        }),
        VectorStore: z.object({
            type: z.string().min(1),
            path: z.string().min(1)
        }),
        Uploads: z.object({
            rootDir: z.string(),
            filesDir: z.string(),
            maxFileSize: z.number().min(1),
            keepExtensions: z.boolean(),
            uploadDirectory: z.string().min(1)
        }),
        useFaqCache: z.boolean(),
        FaqCacheSettings: z.object({
            cacheApiUrl: z.string().url(),
            vectorSimilarityThreshold: z.number().min(0).max(1),
            crossEncoderThreshold: z.number().min(0).max(1)
        }),
        mode: z.array(z.string()), // choose how to preprocess the documents
        PreProcess: z.object({
            PDF: PreProcessConfig,
            DOC: PreProcessConfig,
            Default: PreProcessConfig
        }),
        Retrieval: z.object({
            usingRerank: z.boolean(),
            throwErrorWhenCUDAUnavailable: z.boolean(),
            HybridSearch: RAGHybridSearchConfig,
            topK: z.number().min(1),
            topKForEachCollection: z.number().min(1),
            usingNeighborChunkAware: z.boolean()
        })
    }),
    ResponseFormatPrompt: z.object({
        General: ResponseFormatPrompt,
        FollowUpQuestion: ResponseFormatPrompt
    }),
    AZURE_AD: z.object({
        TENANT_ID: z.string().min(1),
        CLIENT_ID: z.string().min(1),
        CLIENT_SECRET: z.string().min(1),
        REDIRECT_URI: z.string().min(1)
    })
});

export type AppConfig = z.infer<typeof AppConfigSchema>;
