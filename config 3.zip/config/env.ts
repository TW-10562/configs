import dotenv from 'dotenv';
dotenv.config();

export const env = {
  UPLOAD_ROOT: process.env.UPLOAD_DIR || 'uploads',
}